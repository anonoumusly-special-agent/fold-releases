"""Lokaler Dateiindex mit semantischer Suche über einen externen llama-server."""
import argparse, base64, io, json, logging, ntpath, os, re, shutil, sqlite3, subprocess, sys, tempfile, threading, time, wave
import urllib.error, urllib.parse, urllib.request
import xml.etree.ElementTree as ET
import zipfile
from contextlib import closing
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import numpy as np
from pypdf import PdfReader

VERSION = "0.3.0"
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0
WINDOW_S, STEP_S = 30, 25
TEXT = {".txt", ".md", ".csv"}
CODE = {".py", ".js", ".ts", ".tsx", ".jsx", ".java", ".cs", ".cpp",
        ".c", ".h", ".go", ".rs", ".rb", ".php", ".ps1", ".sh",
        ".sql", ".html", ".css", ".json", ".yaml", ".yml", ".toml"}
IMAGE = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".gif"}
AUDIO = {".mp3", ".wav", ".m4a", ".flac", ".ogg", ".opus", ".aac"}
VIDEO = {".mp4", ".mkv", ".mov", ".webm", ".avi", ".m4v"}
DEFAULTS = {"server": "http://127.0.0.1:18090", "port": 18091,
            "db": str(Path(__file__).with_name("fastsearch.db")), "folders": [],
            "exclude_dirs": ["node_modules", ".git", ".venv", "__pycache__",
                             "SteamLibrary", "Riot Games", "Epic Games"],
            "game_exes": ["VALORANT-Win64-Shipping.exe"], "max_file_mb": 50,
            "ffmpeg": ""}

def long_path(path, windows=None):
    path = os.fspath(path)
    if windows is None:
        windows = os.name == "nt"
    if not windows or path.startswith("\\\\?\\"):
        return path
    path = ntpath.normpath(ntpath.abspath(path))
    return "\\\\?\\UNC\\" + path[2:] if path.startswith("\\\\") else "\\\\?\\" + path

def resolve_executable(name, configured="", env=None, base_dirs=None, windows=None):
    env = os.environ if env is None else env
    windows = os.name == "nt" if windows is None else windows
    suffix = ".exe" if windows else ""
    if configured:
        folder = Path(configured).expanduser()
        candidate = (folder.parent if folder.suffix.casefold() == ".exe" or folder.is_file() else folder) / f"{name}{suffix}"
        if candidate.is_file():
            return str(candidate.resolve())
    found = shutil.which(name)
    if found:
        return str(Path(found).resolve())
    if windows and env.get("LOCALAPPDATA"):
        local = Path(env["LOCALAPPDATA"]) / "Microsoft" / "WinGet"
        candidate = local / "Links" / f"{name}.exe"
        if candidate.is_file():
            return str(candidate.resolve())
        for candidate in sorted((local / "Packages").glob(f"Gyan.FFmpeg*/**/bin/{name}.exe")):
            if candidate.is_file():
                return str(candidate.resolve())
    if base_dirs is None:
        if windows:
            base_dirs = ([Path(env["ProgramFiles"]) / "ffmpeg" / "bin"] if env.get("ProgramFiles") else [])
            base_dirs.append(Path(r"C:\ffmpeg\bin"))
        else:
            base_dirs = [Path("/opt/homebrew/bin"), Path("/usr/local/bin")]
    for folder in base_dirs:
        candidate = Path(folder) / f"{name}{suffix}"
        if candidate.is_file():
            return str(candidate.resolve())
    return None

def load_config(path=None):
    path = Path(path) if path else Path(__file__).with_name("config.json")
    config = DEFAULTS.copy()
    config.update(json.loads(path.read_text(encoding="utf-8-sig")))
    config["db"] = os.path.realpath(os.path.expanduser(os.path.expandvars(config["db"])))
    config["folders"] = [os.path.realpath(os.path.expanduser(os.path.expandvars(p))) for p in config["folders"]]
    config["server"] = config["server"].rstrip("/")
    return config

class EmbeddingTooLarge(RuntimeError):
    pass

class ServerUnavailable(RuntimeError):
    pass

def request_json(url, body=None, timeout=300, retry_deadline=None):
    data = None if body is None else json.dumps(body).encode("utf-8")
    request = urllib.request.Request(url, data=data,
                                     headers={"Content-Type": "application/json"} if data else {})
    deadline = retry_deadline if retry_deadline is not None else time.monotonic() + timeout
    while True:
        try:
            with urllib.request.urlopen(request, timeout=min(timeout, 30) if retry_deadline is not None else timeout) as response:
                return json.load(response)
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace").strip()
            message = f"Embedding-Server {url}: HTTP {exc.code}: {detail or exc.reason}"
            if "too large to process" in detail.casefold():
                raise EmbeddingTooLarge(message) from exc
            raise RuntimeError(message) from exc
        except (urllib.error.URLError, OSError) as exc:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                message = f"Embedding-Server {url} nicht erreichbar: {exc}"
                if sys.stdout is not None:
                    print(message, flush=True)
                raise ServerUnavailable(message) from exc
            if sys.stdout is not None:
                print("Server nicht erreichbar, warte 10 s ...", flush=True)
            time.sleep(min(10, remaining))
        except ValueError as exc:
            raise RuntimeError(f"Embedding-Server {url}: {exc}") from exc

def marker(server, timeout=300, retry_deadline=None):
    props = request_json(server + "/props", timeout=timeout, retry_deadline=retry_deadline)
    value = props.get("media_marker") if isinstance(props, dict) else None
    if not isinstance(value, str) or not value:
        raise RuntimeError("Embedding-Server /props enthält keinen media_marker")
    return value

def embedding(server, content, current_marker=None, retry_deadline=None):
    for attempt in range(2):
        try:
            payload = ({"prompt_string": current_marker, "multimodal_data": [content]}
                       if current_marker is not None else content)
            rows = request_json(server + "/embedding", {"content": payload}, retry_deadline=retry_deadline)[0]["embedding"]
            if not rows or not rows[0] or any(len(row) != len(rows[0]) for row in rows):
                raise ValueError("leere oder unterschiedlich lange Embedding-Zeilen")
            vector = np.asarray(rows, dtype=np.float64).mean(axis=0)
            norm = np.linalg.norm(vector)
            if not np.isfinite(norm) or norm == 0 or not np.all(np.isfinite(vector)):
                raise ValueError("Embedding hat keine gültige Norm")
            return (vector / norm).astype(np.float32)
        except EmbeddingTooLarge:
            if current_marker is not None:
                raise
            if len(content) <= 64:
                logging.warning("Chunk übersprungen: auch bei %d Zeichen zu groß", len(content))
                if sys.stdout is not None:
                    print(f"Chunk übersprungen: auch bei {len(content)} Zeichen zu groß", flush=True)
                return None
            middle = len(content) // 2
            left = embedding(server, content[:middle], retry_deadline=retry_deadline)
            right = embedding(server, content[middle:], retry_deadline=retry_deadline)
            if left is None or right is None:
                return left if right is None else right
            vector = left.astype(np.float64) * middle + right.astype(np.float64) * (len(content) - middle)
            norm = np.linalg.norm(vector)
            return left if norm == 0 else (vector / norm).astype(np.float32)
        except ServerUnavailable:
            raise
        except (RuntimeError, ValueError, TypeError, KeyError, IndexError) as exc:
            if attempt:
                raise RuntimeError(f"Embedding fehlgeschlagen: {exc}") from exc
            fresh_marker = marker(server, retry_deadline=retry_deadline)
            if current_marker is not None:
                current_marker = fresh_marker

def image_base64(path, ffmpeg="ffmpeg"):
    with tempfile.TemporaryDirectory() as temp:
        output = Path(temp) / "image.jpg"
        for size in (768, 512, 384, 256):
            subprocess.run([ffmpeg, "-hide_banner", "-loglevel", "error", "-y",
                            "-i", str(path), "-vf",
                            f"scale={size}:{size}:force_original_aspect_ratio=decrease,sidedata=mode=delete",
                            "-frames:v", "1", "-q:v", "3", "-map_metadata", "-1", str(output)],
                           check=True, capture_output=True, stdin=subprocess.DEVNULL,
                           creationflags=NO_WINDOW)
            encoded = base64.b64encode(output.read_bytes()).decode("ascii")
            if len(encoded) < 900_000:
                return encoded
    raise ValueError(f"Bild bleibt für den Server zu groß: {path}")

def wav_windows(path):
    with wave.open(long_path(path), "rb") as source:
        rate = source.getframerate()
        total = source.getnframes()
        for start in range(0, total, STEP_S * rate):
            count = min(WINDOW_S * rate, total - start)
            if count < 2 * rate:
                break
            source.setpos(start)
            with io.BytesIO() as buffer:
                with wave.open(buffer, "wb") as output:
                    output.setparams(source.getparams())
                    output.writeframes(source.readframes(count))
                yield start // rate, (start + count + rate - 1) // rate, buffer.getvalue()

def read_text(path, kind):
    path = long_path(path)
    if kind in ("text", "code"):
        return Path(path).read_text(encoding="utf-8-sig", errors="replace")
    if kind == "pdf":
        return "\n".join(page.extract_text() or "" for page in PdfReader(path).pages)
    with zipfile.ZipFile(path) as archive:
        root = ET.fromstring(archive.read("word/document.xml"))
    ns = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    return "\n".join("".join(node.text or "" for node in paragraph.iter(ns + "t"))
                     for paragraph in root.iter(ns + "p"))

def chunks(text, kind):
    if kind == "code":
        lines = text.splitlines(keepends=True)
        start, part, length = 1, [], 0
        for number, line in enumerate(lines, 1):
            for offset in range(0, len(line), 1800):
                segment = line[offset:offset + 1800]
                if part and length + len(segment) > 1800:
                    yield "".join(part), start, number if offset else number - 1
                    start, part, length = number, [], 0
                part.append(segment)
                length += len(segment)
        if part and "".join(part).strip():
            yield "".join(part), start, len(lines)
    else:
        for start in range(0, len(text), 1600):
            part = text[start:start + 1800]
            if part.strip():
                yield part, None, None
            if start + 1800 >= len(text):
                break

class SearchService:
    def __init__(self, config):
        self.config = config
        db = Path(config["db"])
        db.parent.mkdir(parents=True, exist_ok=True)
        self.db = str(db)
        self.conn = self.connect()
        self.lock = threading.Lock()
        self.cache_version = None
        self.game_checked = 0.0
        self.game_running = False
        self.conn.executescript("""
            CREATE TABLE IF NOT EXISTS files (id INTEGER PRIMARY KEY, path TEXT UNIQUE,
                size INTEGER, mtime INTEGER, kind TEXT);
            CREATE TABLE IF NOT EXISTS chunks (id INTEGER PRIMARY KEY, file_id INTEGER,
                kind TEXT, start INTEGER, end INTEGER, text TEXT, vec BLOB);
            CREATE INDEX IF NOT EXISTS chunks_file ON chunks(file_id);
            CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING fts5(
                text, content='chunks', content_rowid='id');
            CREATE TRIGGER IF NOT EXISTS chunks_ai AFTER INSERT ON chunks BEGIN
                INSERT INTO chunks_fts(rowid, text) VALUES (new.id, new.text);
            END;
            CREATE TRIGGER IF NOT EXISTS chunks_ad BEFORE DELETE ON chunks BEGIN
                INSERT INTO chunks_fts(chunks_fts, rowid, text) VALUES ('delete', old.id, old.text);
            END;
        """)

    def connect(self):
        conn = sqlite3.connect(self.db, timeout=30, check_same_thread=False)
        conn.execute("PRAGMA journal_mode=WAL")
        return conn

    def close(self):
        self.conn.close()

    def pause_for_game(self):
        if os.name != "nt":
            return
        while True:
            now = time.monotonic()
            if now - self.game_checked >= 30 or not self.game_checked:
                self.game_checked = now
                self.game_running = False
                for exe in self.config["game_exes"]:
                    try:
                        result = subprocess.run(["tasklist", "/FI", f"IMAGENAME eq {exe}", "/NH"],
                                                capture_output=True, stdin=subprocess.DEVNULL,
                                                text=True, errors="replace", timeout=10,
                                                creationflags=NO_WINDOW)
                    except (OSError, subprocess.TimeoutExpired):
                        break
                    if result.returncode == 0 and exe.casefold() in result.stdout.casefold():
                        self.game_running = True
                        break
            if not self.game_running:
                return
            time.sleep(60)

    def media_chunks(self, source, kind, current_marker, ffmpeg, ffprobe):
        with tempfile.TemporaryDirectory() as temp:
            temp = Path(temp)
            wav = temp / "audio.wav"
            if kind == "audio" or subprocess.run(
                    [ffprobe, "-v", "error", "-select_streams", "a:0",
                     "-show_entries", "stream=index", "-of", "csv=p=0", str(source)],
                    check=True, capture_output=True, text=True, stdin=subprocess.DEVNULL,
                    creationflags=NO_WINDOW).stdout.strip():
                subprocess.run([ffmpeg, "-hide_banner", "-loglevel", "error", "-y",
                                "-i", str(source), "-map", "0:a:0", "-ar", "16000",
                                "-ac", "1", "-c:a", "pcm_s16le", str(wav)],
                               check=True, capture_output=True, stdin=subprocess.DEVNULL,
                               creationflags=NO_WINDOW)
                for start, end, data in wav_windows(wav):
                    self.pause_for_game()
                    yield start, end, embedding(self.config["server"],
                                                base64.b64encode(data).decode("ascii"), current_marker)
            if kind == "video":
                frames = temp / "frame_%05d.jpg"
                thumbs = temp / "thumbs.raw"
                subprocess.run([ffmpeg, "-hide_banner", "-loglevel", "error", "-y",
                                "-i", str(source), "-filter_complex",
                                "[0:v]fps=1/3,split=2[large][small];"
                                "[large]scale=768:-2[jpg];[small]scale=16:16,format=gray[raw]",
                                "-map", "[jpg]", "-q:v", "3", str(frames),
                                "-map", "[raw]", "-f", "rawvideo", str(thumbs)],
                               check=True, capture_output=True, stdin=subprocess.DEVNULL,
                               creationflags=NO_WINDOW)
                small = np.fromfile(thumbs, dtype=np.uint8)
                if small.size % 256:
                    raise ValueError("Unvollständige Video-Vorschaubilder")
                previews = small.reshape(-1, 256)
                pictures = sorted(temp.glob("frame_*.jpg"))
                if len(pictures) != len(previews):
                    raise ValueError("Video-Frames und Vorschaubilder stimmen nicht überein")
                previous = None
                for number, (picture, preview) in enumerate(zip(pictures, previews)):
                    self.pause_for_game()
                    if previous is not None and np.abs(preview.astype(np.int16) - previous.astype(np.int16)).mean() < 6:
                        continue
                    previous = preview
                    start = number * 3
                    yield start, start + 3, embedding(self.config["server"],
                                                      base64.b64encode(picture.read_bytes()).decode("ascii"),
                                                      current_marker)

    def index(self):
        config = self.config
        ffmpeg = resolve_executable("ffmpeg", config["ffmpeg"])
        ffprobe = resolve_executable("ffprobe", config["ffmpeg"])
        known = {path: (file_id, size, mtime, kind) for file_id, path, size, mtime, kind
                 in self.conn.execute("SELECT id, path, size, mtime, kind FROM files")}
        found, roots, failed = {}, [], [False]
        excluded = {name.casefold() for name in config["exclude_dirs"]}
        for folder in config["folders"]:
            resolved = os.path.realpath(long_path(folder))
            if os.name == "nt" and resolved.startswith("\\\\?\\UNC\\"):
                resolved = "\\\\" + resolved[8:]
            elif os.name == "nt" and resolved.startswith("\\\\?\\"):
                resolved = resolved[4:]
            root = Path(resolved)
            walk_root = long_path(root)
            if not Path(walk_root).is_dir():
                logging.error("Ordner nicht lesbar: %s", root)
                continue
            roots.append(root)
            def walk_error(error):
                logging.error("Crawler: %s", error)
                failed[0] = True
            for directory, dirs, names in os.walk(walk_root, onerror=walk_error):
                dirs[:] = [name for name in dirs if not name.startswith(".")
                           and name.casefold() not in excluded]
                for name in names:
                    path = root / os.path.relpath(directory, walk_root) / name
                    suffix = path.suffix.casefold()
                    kind = ("text" if suffix in TEXT else "code" if suffix in CODE else
                            "image" if suffix in IMAGE else "audio" if suffix in AUDIO else
                            "video" if suffix in VIDEO else
                            "pdf" if suffix == ".pdf" else "docx" if suffix == ".docx" else None)
                    if kind is None:
                        continue
                    try:
                        stat = Path(long_path(path)).stat()
                    except OSError as exc:
                        logging.error("Datei %s: %s", path, exc)
                        failed[0] = True
                        continue
                    if kind in ("audio", "video") or stat.st_size <= config["max_file_mb"] * 1024 * 1024:
                        found[str(path)] = (stat.st_size, stat.st_mtime_ns, kind)
        deleted = [path for path in known if path not in found and not failed[0]
                   and any(Path(path).is_relative_to(root) for root in roots)]
        changed = [(path, *info) for path, info in found.items()
                   if path not in known or info != known[path][1:]]
        skipped_media = {path for path, _, _, kind in changed
                         if kind in ("image", "audio", "video") and
                         (not ffmpeg or (kind == "video" and not ffprobe))}
        if skipped_media:
            message = 'ffmpeg fehlt, Bilder/Audio/Video werden übersprungen (config-Key "ffmpeg" setzen oder ffmpeg installieren)'
            if sys.stdout is not None:
                print(message, flush=True)
            logging.warning("%s", message)
        counts = {"new": sum(path not in known and path not in skipped_media for path, *_ in changed),
                  "changed": sum(path in known and path not in skipped_media for path, *_ in changed),
                  "deleted": len(deleted), "skipped": len(found) - len(changed)}
        if sys.stdout is not None:
            print("Index-Start: {new} neu, {changed} geändert, {deleted} gelöscht, "
                  "{skipped} übersprungen".format(**counts), flush=True)
        if not changed and not deleted:
            return counts
        with closing(self.connect()) as conn:
            for path in deleted:
                conn.execute("DELETE FROM chunks WHERE file_id=?", (known[path][0],))
                conn.execute("DELETE FROM files WHERE id=?", (known[path][0],))
            conn.commit()
            current_marker = marker(config["server"]) if len(changed) > len(skipped_media) else None
            for path, size, mtime, kind in changed:
                if path in skipped_media:
                    continue
                try:
                    self.pause_for_game()
                    source = Path(path)
                    if kind in ("audio", "video"):
                        records = [("", start, end, vector) for start, end, vector
                                   in self.media_chunks(source, kind, current_marker, ffmpeg, ffprobe)]
                    else:
                        parts = [(source.name, None, None)] if kind == "image" else list(chunks(read_text(source, kind), kind))
                        vectors = [embedding(config["server"], image_base64(source, ffmpeg), current_marker)] if kind == "image" else [
                            embedding(config["server"], f"title: {source.name} | text: {part}")
                            for part, _, _ in parts]
                        records = [(part, start, end, vector) for (part, start, end), vector in zip(parts, vectors)
                                   if vector is not None]
                        if parts and not records:
                            continue
                    if path in known:
                        file_id = known[path][0]
                        conn.execute("DELETE FROM chunks WHERE file_id=?", (file_id,))
                        conn.execute("UPDATE files SET size=?, mtime=?, kind=? WHERE id=?",
                                     (size, mtime, kind, file_id))
                    else:
                        file_id = conn.execute("INSERT INTO files(path, size, mtime, kind) VALUES(?,?,?,?)",
                                               (path, size, mtime, kind)).lastrowid
                    conn.executemany("INSERT INTO chunks(file_id, kind, start, end, text, vec) VALUES(?,?,?,?,?,?)",
                                     [(file_id, kind, start, end, part, vector.tobytes())
                                      for part, start, end, vector in records])
                    conn.commit()
                except ServerUnavailable:
                    conn.rollback()
                    raise
                except Exception as exc:
                    conn.rollback()
                    if kind in ("image", "audio", "video"):
                        detail = str(exc)
                        if isinstance(exc, subprocess.CalledProcessError) and exc.stderr:
                            stderr = exc.stderr.decode(errors="replace") if isinstance(exc.stderr, bytes) else exc.stderr
                            lines = [line.strip() for line in stderr.splitlines() if line.strip()]
                            if lines:
                                detail += f": {lines[-1]}"
                        logging.warning("Datei übersprungen: %s: %s", path, detail)
                        if sys.stdout is not None:
                            print(f"Datei übersprungen: {path}: {detail}", flush=True)
                    else:
                        logging.error("Datei %s: %s", path, exc)
        return counts

    def search(self, q, k=20):
        if not q.strip() or k <= 0:
            return []
        code = q[:5].casefold() == "code:"
        query = q[5:].strip() if code else q.strip()
        if not query:
            return []
        prompt = "task: code retrieval | query: " if code else "task: search result | query: "
        retry_deadline = time.monotonic() + 10
        marker(self.config["server"], retry_deadline=retry_deadline)
        vector = embedding(self.config["server"], prompt + query, retry_deadline=retry_deadline)
        if vector is None:
            raise RuntimeError("Suchanfrage ist für den Embedding-Server zu groß")
        with self.lock:
            version = self.conn.execute("PRAGMA data_version").fetchone()[0]
            if version != self.cache_version:
                rows = self.conn.execute("SELECT c.id, f.path, c.kind, c.start, c.end, c.text, c.vec "
                                         "FROM chunks c JOIN files f ON f.id=c.file_id").fetchall()
                self.rows = rows
                self.matrix = np.vstack([np.frombuffer(row[6], dtype=np.float32) for row in rows]) if rows else np.empty((0, 0), dtype=np.float32)
                self.cache_version = version
            if not self.rows:
                return []
            if vector.size != self.matrix.shape[1]:
                raise RuntimeError("Embedding-Dimension passt nicht zum Index; bitte neu indexieren")
            words = re.findall(r"\w+", query, re.UNICODE)[:100]
            hits = set()
            if words:
                expression = " OR ".join('"' + word + '"' for word in words)
                hits = {row[0] for row in self.conn.execute(
                    "SELECT rowid FROM chunks_fts WHERE chunks_fts MATCH ?", (expression,))}
            # ponytail: Brute-Force-Matrixsuche bis etwa 200k Chunks; danach ANN-Index einsetzen.
            scores = self.matrix @ vector
            best = {}
            for row, score in zip(self.rows, scores):
                chunk_id, path, kind, start, end, snippet, _ = row
                if (kind == "code") != code:
                    continue
                score = float(score) + (0.05 if chunk_id in hits else 0.0)
                if path not in best or score > best[path][0]:
                    best[path] = (score, {"path": path, "kind": kind, "score": round(score, 4),
                                          "snippet": "" if kind == "image" else snippet[:200],
                                          "start": start, "end": end})
            return [item for _, item in sorted(best.values(), key=lambda pair: pair[0], reverse=True)[:k]]

    def status(self):
        with self.lock:
            files = self.conn.execute("SELECT count(*) FROM files").fetchone()[0]
            chunks_count = self.conn.execute("SELECT count(*) FROM chunks").fetchone()[0]
        try:
            marker(self.config["server"], timeout=2)
            server_ok = True
        except RuntimeError:
            server_ok = False
        return {"version": VERSION, "files": files, "chunks": chunks_count,
                "server_ok": server_ok, "db": self.db}

def make_server(service, port=None):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, format, *args):
            pass

        def do_GET(self):
            port = self.server.server_address[1]
            if (self.headers.get_all("Host", []) not in ([f"127.0.0.1:{port}"], [f"localhost:{port}"])
                    or self.headers.get("Origin") is not None):
                self.reply(403, {"error": "Ungültiger Host oder Origin."})
                return
            parsed = urllib.parse.urlsplit(self.path)
            args = urllib.parse.parse_qs(parsed.query)
            try:
                if parsed.path == "/status":
                    self.reply(200, service.status())
                elif parsed.path == "/folders":
                    self.reply(200, {"folders": [os.path.realpath(folder) for folder in service.config["folders"]]})
                elif parsed.path == "/search":
                    k = int(args.get("k", ["20"])[0])
                    self.reply(200, {"results": service.search(args.get("q", [""])[0], k)})
                elif parsed.path == "/read":
                    path = os.path.realpath(args.get("path", [""])[0])
                    allowed = False
                    for folder in service.config["folders"]:
                        root = os.path.realpath(folder)
                        try:
                            allowed = os.path.normcase(os.path.commonpath((path, root))) == os.path.normcase(root)
                        except ValueError:  # Different drives on Windows.
                            pass
                        if allowed:
                            break
                    if not allowed:
                        self.reply(403, {"error": "Datei liegt außerhalb der freigegebenen Ordner."})
                        return
                    suffix = Path(path).suffix.casefold()
                    kind = ("text" if suffix in TEXT else "code" if suffix in CODE else
                            "pdf" if suffix == ".pdf" else "docx" if suffix == ".docx" else None)
                    if kind is None:
                        self.reply(415, {"error": "Nur Text, Code, PDF und DOCX können gelesen werden; Bilder, Audio und Video nicht."})
                        return
                    if not os.path.isfile(path):
                        self.reply(404, {"error": "Datei nicht gefunden."})
                        return
                    limit = int(args.get("max", ["20000"])[0])
                    if limit < 0:
                        raise ValueError("max muss mindestens 0 sein")
                    content = read_text(path, kind)
                    self.reply(200, {"path": path, "text": content[:limit], "truncated": len(content) > limit})
                else:
                    self.reply(404, {"error": "Not found"})
            except ValueError as exc:
                self.reply(400, {"error": str(exc)})
            except (RuntimeError, sqlite3.Error) as exc:
                self.reply(503, {"error": str(exc)})
            except OSError as exc:
                self.reply(500, {"error": f"Datei konnte nicht gelesen werden: {exc}"})

        def reply(self, status, body):
            data = json.dumps(body, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

    return ThreadingHTTPServer(("127.0.0.1", service.config["port"] if port is None else port), Handler)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("index", "serve"))
    parser.add_argument("--config", type=Path)
    args = parser.parse_args()
    try:
        config = load_config(args.config)
    except (OSError, ValueError) as exc:
        if sys.stderr is not None:
            logging.basicConfig(level=logging.ERROR,
                                format="%(asctime)s %(levelname)s: %(message)s")
            logging.error("%s", exc)
        return 1
    try:
        db_dir = Path(config["db"]).parent
        db_dir.mkdir(parents=True, exist_ok=True)
        logging.basicConfig(filename=str(db_dir / "fastsearch.log"), level=logging.WARNING,
                            format="%(asctime)s %(levelname)s: %(message)s")
        service = SearchService(config)
        try:
            if args.command == "index":
                service.index()
            else:
                with make_server(service) as server:
                    server.serve_forever()
        finally:
            service.close()
        return 0
    except (OSError, ValueError, RuntimeError, sqlite3.Error) as exc:
        if logging.getLogger().handlers or sys.stderr is not None:
            logging.error("%s", exc)
        return 1
if __name__ == "__main__":
    raise SystemExit(main())
