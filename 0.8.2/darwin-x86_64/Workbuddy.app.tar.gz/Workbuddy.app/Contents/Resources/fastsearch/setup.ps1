<#
Windows PowerShell 5.1, from the repository root:
Unblock-File -Path .\fastsearch\setup.ps1
powershell -ExecutionPolicy Bypass -File .\fastsearch\setup.ps1
#>
param(
    [switch]$Uninstall,
    [switch]$Purge
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
try { [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding $false } catch {}
trap {
    Write-Output ("FEHLER: " + ($_.Exception.Message -replace '\r?\n', ' '))
    exit 1
}
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$appDir = Join-Path $env:APPDATA 'Workbuddy'
$localDir = Join-Path $env:LOCALAPPDATA 'Workbuddy'
$binDir = Join-Path $localDir 'bin'
$modelDir = Join-Path $localDir 'models'
$venvDir = Join-Path $localDir 'venv'
$config = Join-Path $appDir 'config.json'
$modelFile = Join-Path $appDir 'model.txt'
$ownedModels = Join-Path $localDir 'ollama-models-installed.txt'
$tasks = @('Workbuddy-Ollama', 'Workbuddy-Embed', 'Workbuddy-Search',
           'Workbuddy-Index', 'Workbuddy-Whisper')

if ($Purge -and -not $Uninstall) { throw '-Purge ist nur zusammen mit -Uninstall erlaubt.' }

function Find-Ollama {
    $command = Get-Command ollama -ErrorAction SilentlyContinue
    if ($command) { return $command.Source }
    $candidate = Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama.exe'
    if (Test-Path -LiteralPath $candidate) { return $candidate }
    return $null
}

function Wait-Ollama {
    for ($attempt = 0; $attempt -lt 30; $attempt++) {
        try { return Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/tags' -TimeoutSec 2 }
        catch { Start-Sleep -Seconds 1 }
    }
    throw 'Ollama antwortet nicht auf Port 11434. Bitte Ollama starten und das Setup erneut ausfuehren.'
}

if ($Uninstall) {
    Write-Host 'Workbuddy-Dienste entfernen ...'
    foreach ($name in $tasks) {
        if (Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue) {
            Stop-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue
            Unregister-ScheduledTask -TaskName $name -Confirm:$false
        }
    }
    $ollama = Find-Ollama
    if ((Test-Path -LiteralPath $ownedModels) -and $ollama) {
        try {
            $null = Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/tags' -TimeoutSec 2
        } catch {
            Start-Process -FilePath $ollama -ArgumentList 'serve' -WindowStyle Hidden
            $null = Wait-Ollama
        }
        foreach ($model in (Get-Content -LiteralPath $ownedModels | Select-Object -Unique)) {
            & $ollama rm $model
            if ($LASTEXITCODE -ne 0) { throw "Ollama-Modell $model konnte nicht entfernt werden." }
        }
    } elseif (Test-Path -LiteralPath $ownedModels) {
        Write-Warning 'Ollama fehlt. Die von Workbuddy geladenen Ollama-Modelle bitte mit ollama rm entfernen.'
    }
    foreach ($id in @('Gyan.FFmpeg', 'Ollama.Ollama', 'Python.Python.3.11')) {
        $marker = Join-Path $localDir ("installed-$id")
        if (Test-Path -LiteralPath $marker) {
            & winget uninstall -e --id $id --silent
            if ($LASTEXITCODE -ne 0) { throw "Programm $id konnte nicht entfernt werden." }
            Remove-Item -LiteralPath $marker
        }
    }
    foreach ($path in @($binDir, $modelDir, $venvDir, $ownedModels,
                        (Join-Path $appDir 'fastsearch.py'),
                        (Join-Path $appDir 'ollama-start.ps1'), $modelFile)) {
        if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Recurse -Force }
    }
    if ($Purge) {
        foreach ($path in @($appDir, $localDir)) {
            if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Recurse -Force }
        }
        Write-Host 'Dienste, Programme, Modelle, Konfiguration und Index entfernt.'
    } else {
        Write-Host "Konfiguration und Index bleiben unter $appDir und $localDir erhalten."
    }
    return
}

function Install-WingetPackage($id, $scope) {
    if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
        throw 'winget fehlt. Bitte App Installer installieren und das Setup erneut starten.'
    }
    $arguments = @('install', '-e', '--id', $id, '--silent', '--disable-interactivity',
                   '--accept-package-agreements', '--accept-source-agreements')
    if ($scope) { $arguments += @('--scope', $scope) }
    & winget @arguments
    if ($LASTEXITCODE -ne 0) { throw "Programm $id konnte nicht installiert werden." }
    New-Item -ItemType File -Path (Join-Path $localDir ("installed-$id")) -Force | Out-Null
    $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' +
                [Environment]::GetEnvironmentVariable('Path', 'User')
}

function Find-Python {
    if (Get-Command py -ErrorAction SilentlyContinue) {
        $found = & py -3.11 -c 'import sys; print(sys.executable)' 2>$null
        if ($LASTEXITCODE -eq 0 -and $found -and (Test-Path -LiteralPath $found)) { return $found.Trim() }
    }
    $candidate = Join-Path $env:LOCALAPPDATA 'Programs\Python\Python311\python.exe'
    if (Test-Path -LiteralPath $candidate) { return $candidate }
    return $null
}

function Download-Model($url, $target, [Parameter(Mandatory=$true)][string]$sha256) {
    if (Test-Path -LiteralPath $target) {
        if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -eq $sha256) {
            Write-Host "$(Split-Path -Leaf $target) ist schon vorhanden."
            return
        }
    }
    $part = "$target.part"
    Invoke-WebRequest -Uri $url -OutFile $part -UseBasicParsing
    if ((Get-Item -LiteralPath $part).Length -le 100MB) {
        throw "Download von $(Split-Path -Leaf $target) ist zu klein."
    }
    if ((Get-FileHash -LiteralPath $part -Algorithm SHA256).Hash -ne $sha256) {
        Remove-Item -LiteralPath $part -Force
        throw [System.IO.InvalidDataException]::new("SHA256-Pruefung fehlgeschlagen: $(Split-Path -Leaf $target).")
    }
    Move-Item -LiteralPath $part -Destination $target -Force
}

function Expand-Release($url, $name, $destination, [Parameter(Mandatory=$true)][string]$sha256) {
    $zip = Join-Path $destination $name
    if (-not (Test-Path -LiteralPath $zip)) {
        Invoke-WebRequest -Uri $url -OutFile "$zip.part" -UseBasicParsing
        Move-Item -LiteralPath "$zip.part" -Destination $zip -Force
    }
    if ((Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash -ne $sha256) {
        Remove-Item -LiteralPath $zip -Force
        throw [System.IO.InvalidDataException]::new("SHA256-Pruefung fehlgeschlagen: $name.")
    }
    Expand-Archive -LiteralPath $zip -DestinationPath $destination -Force
    Remove-Item -LiteralPath $zip
}

function Find-Server($folder, $name) {
    $found = Get-ChildItem -LiteralPath $folder -Filter $name -File -Recurse |
             Select-Object -First 1
    if (-not $found) { throw "$name fehlt nach dem Entpacken unter $folder." }
    return $found.FullName
}

function Remove-OwnDirectory($folder) {
    foreach ($item in Get-ChildItem -LiteralPath $folder -Force) {
        if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) {
            if ($item.PSIsContainer) { [IO.Directory]::Delete($item.FullName) }
            else { [IO.File]::Delete($item.FullName) }
        } elseif ($item.PSIsContainer) {
            Remove-OwnDirectory $item.FullName
        } else {
            [IO.File]::Delete($item.FullName)
        }
    }
    [IO.Directory]::Delete($folder)
}

Write-Host '1/8: Ordner und Python einrichten ...'
foreach ($dir in @($appDir, $localDir, $binDir, $modelDir)) {
    New-Item -ItemType Directory -Path $dir -Force | Out-Null
}
$python = Find-Python
if (-not $python) {
    Install-WingetPackage 'Python.Python.3.11' 'user'
    $python = Find-Python
}
if (-not $python) { throw 'Python 3.11 fehlt nach der Installation. Bitte die Einrichtung erneut starten.' }
$venvPython = Join-Path $venvDir 'Scripts\python.exe'
$venvPythonw = Join-Path $venvDir 'Scripts\pythonw.exe'
if (-not (Test-Path -LiteralPath $venvPython)) { & $python -m venv $venvDir }
if (-not (Test-Path -LiteralPath $venvPythonw)) { throw 'pythonw.exe fehlt in der Python-Umgebung.' }
& $venvPython -m pip install -r (Join-Path $PSScriptRoot 'requirements.txt')
if ($LASTEXITCODE -ne 0) { throw 'Python-Pakete konnten nicht installiert werden.' }

Write-Host '2/8: Ollama und ffmpeg einrichten ...'
$ollama = Find-Ollama
if (-not $ollama) {
    Install-WingetPackage 'Ollama.Ollama' 'user'
    $ollama = Find-Ollama
}
if (-not $ollama) { throw 'Ollama fehlt nach der Installation. Bitte die Einrichtung erneut starten.' }
if (-not (Get-Command ffmpeg -ErrorAction SilentlyContinue) -and
    -not (Test-Path -LiteralPath (Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Links\ffmpeg.exe'))) {
    Install-WingetPackage 'Gyan.FFmpeg' ''
}

Write-Host '3/8: FastSearch und Konfiguration einrichten ...'
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'fastsearch.py') -Destination (Join-Path $appDir 'fastsearch.py') -Force
if (-not (Test-Path -LiteralPath $config)) {
    $settings = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'config.example.json') -Raw | ConvertFrom-Json
    $settings.db = Join-Path $localDir 'fastsearch.db'
    $settings.folders = @('Documents', 'Desktop', 'Downloads') | ForEach-Object {
        Join-Path $env:USERPROFILE $_
    }
    $settings | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $config -Encoding UTF8
}

Write-Host '4/8: Embedding- und Whisper-Modelle laden ...'
$hashes = @{
    'app-b12649-mix-c7059d6-windows-x64-cuda12-portable.zip' = '2374ae22658c4e761b1a036fe069f6b5ad45a272e0e909c9cd73362a97b697c1'
    'app-b12649-mix-c7059d6-windows-x64-cpu.zip' = '25416ff13c7a264536e766dff54a8b3520c15b212c810ab49267483940db4db7'
    'whisper-bin-win-cuda-12.4.0-x64.zip' = 'afef0b881c500958921c3f5523b50e59ee2ec9b6f5cbd25b324c51ed308a957a'
    'whisper-bin-x64.zip' = '6ba69e3482d7826214f90a6a9c84ca07782aec1e1d0c6a7c30c994fd5d816ccb'
    'embeddinggemma-2-Q8_0.gguf' = '2188ac1deca4b77dffefd603c2776a9d76d9d74ec01841392982ebb840b09135'
    'mmproj-embeddinggemma-2-Q8_0.gguf' = 'c4a8a52691ecef40618438928bdf9e68379b854e24166f292592353db0aab64f'
    'ggml-large-v3-turbo.bin' = '1fc70f774d38eb169993ac391eea357ef47c88757ef72ee5943879b7e8e2bc69'
}
$modelBase = 'https://huggingface.co/ggml-org/embeddinggemma-2-GGUF/resolve/bfcd298762cc34d0357ece5ebdd31791a3a374d8/'
foreach ($name in @('embeddinggemma-2-Q8_0.gguf', 'mmproj-embeddinggemma-2-Q8_0.gguf')) {
    Download-Model ($modelBase + $name) (Join-Path $modelDir $name) $hashes[$name]
}
Download-Model 'https://huggingface.co/ggerganov/whisper.cpp/resolve/5359861c739e955e79d9a303bcbc70fb988958b1/ggml-large-v3-turbo.bin' `
    (Join-Path $modelDir 'ggml-large-v3-turbo.bin') $hashes['ggml-large-v3-turbo.bin']

Write-Host '5/8: Ollama starten und Modell waehlen ...'
$contextLength = [Environment]::GetEnvironmentVariable('OLLAMA_CONTEXT_LENGTH', 'User')
$parsedContext = 0L
$contextChanged = $false
if (-not $contextLength -or $contextLength -notmatch '^[0-9]+$' -or
    -not [long]::TryParse($contextLength, [ref]$parsedContext) -or $parsedContext -lt 16384) {
    $contextLength = '16384'
    [Environment]::SetEnvironmentVariable('OLLAMA_CONTEXT_LENGTH', $contextLength, 'User')
    $contextChanged = $true
}
$env:OLLAMA_CONTEXT_LENGTH = $contextLength
Write-Host "Ollama-Kontext: $contextLength"
$launcher = Join-Path $appDir 'ollama-start.ps1'
$launcherText = @'
$ollama = '__OLLAMA__'
$launcherContext = [Environment]::GetEnvironmentVariable('OLLAMA_CONTEXT_LENGTH','User')
if ($launcherContext) { $env:OLLAMA_CONTEXT_LENGTH = $launcherContext }
try { Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/tags' -TimeoutSec 2 | Out-Null }
catch { Start-Process -FilePath $ollama -ArgumentList 'serve' -WindowStyle Hidden }
'@
$launcherText.Replace('__OLLAMA__', $ollama.Replace("'", "''")) |
    Set-Content -LiteralPath $launcher -Encoding UTF8
$user = [Security.Principal.WindowsIdentity]::GetCurrent().Name
$principal = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Limited
$logon = New-ScheduledTaskTrigger -AtLogOn -User $user
$longRunning = New-ScheduledTaskSettingsSet -Hidden -ExecutionTimeLimit (New-TimeSpan -Seconds 0) `
    -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) `
    -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew
$ollamaArgs = '-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "{0}"' -f $launcher
$ollamaAction = New-ScheduledTaskAction -Execute (Join-Path $PSHOME 'powershell.exe') -Argument $ollamaArgs
Register-ScheduledTask -TaskName 'Workbuddy-Ollama' -Action $ollamaAction -Trigger $logon `
    -Principal $principal -Settings $longRunning -Force | Out-Null
$ollamaRunning = $false
try {
    $tags = Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/tags' -TimeoutSec 2
    $ollamaRunning = $true
}
catch {
    Start-ScheduledTask -TaskName 'Workbuddy-Ollama'
    $tags = Wait-Ollama
}
if ($contextChanged -and $ollamaRunning) {
    Write-Host 'Ollama wird neu gestartet, damit der groessere Kontext gilt.'
    Get-Process -Name 'ollama','ollama app' -ErrorAction SilentlyContinue | Stop-Process -Force
    Start-Sleep -Seconds 2
    Start-ScheduledTask -TaskName 'Workbuddy-Ollama'
    $tags = Wait-Ollama
}
$ram = (Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory
if (-not $ram) { throw 'Arbeitsspeicher konnte nicht ermittelt werden.' }
$nvidia = [bool](Get-Command nvidia-smi -ErrorAction SilentlyContinue)
$gpuMemory = $null
if ($nvidia) {
    try {
        $gpuLines = @(& nvidia-smi --query-gpu=memory.total --format=csv,noheader,nounits 2>$null)
        $parsedMemory = 0
        if ($LASTEXITCODE -eq 0 -and $gpuLines.Count -gt 0 -and
            ([int]::TryParse(([string]$gpuLines[0]).Trim(), [ref]$parsedMemory))) {
            $gpuMemory = $parsedMemory
        }
    } catch { }
}
if ($null -eq $gpuMemory) { $gpuReason = 'keine NVIDIA-Karte erkannt' }
else { $gpuReason = "$gpuMemory MiB NVIDIA-VRAM" }
if ($ram -ge 48GB -and ($null -eq $gpuMemory -or $gpuMemory -ge 28000)) {
    $selectedModel = 'qwen3.5:35b'
    $modelReason = "mindestens 48 GB RAM, $gpuReason"
} elseif ($ram -ge 24GB -and ($null -eq $gpuMemory -or $gpuMemory -ge 20000)) {
    $selectedModel = 'qwen3.5:27b'
    $modelReason = "mindestens 24 GB RAM, $gpuReason"
} else {
    $selectedModel = 'qwen3.5:9b'
    $modelReason = "RAM- oder VRAM-Grenze nicht erreicht ($gpuReason)"
}
Write-Host "Modellwahl: $selectedModel ($modelReason)"
$present = @($tags.models | ForEach-Object { $_.name })
if ($selectedModel -notin $present) {
    & $ollama pull $selectedModel
    if ($LASTEXITCODE -ne 0) {
        if ($selectedModel -eq 'qwen3.5:9b') { throw 'Ollama-Modell qwen3.5:9b konnte nicht geladen werden.' }
        Write-Host "Download von $selectedModel fehlgeschlagen. Verwende qwen3.5:9b."
        $selectedModel = 'qwen3.5:9b'
        if ($selectedModel -notin $present) {
            & $ollama pull $selectedModel
            if ($LASTEXITCODE -ne 0) { throw 'Ollama-Modell qwen3.5:9b konnte nicht geladen werden.' }
        }
    }
    if ($selectedModel -notin $present -and
        (-not (Test-Path -LiteralPath $ownedModels) -or $selectedModel -notin (Get-Content -LiteralPath $ownedModels))) {
        Add-Content -LiteralPath $ownedModels -Value $selectedModel
    }
}
Set-Content -LiteralPath $modelFile -Value $selectedModel -Encoding ASCII
Write-Host "Ollama-Modell: $selectedModel"

Write-Host '6/8: Windows-Server bereitstellen ...'
$llamaDir = Join-Path $binDir 'llama'
$whisperDir = Join-Path $binDir 'whisper'
New-Item -ItemType Directory -Path $whisperDir -Force | Out-Null
$llamaBuild = 'b12649-mix-c7059d6'
if ((Test-Path -LiteralPath $llamaDir) -and
    ((Get-Item -LiteralPath $llamaDir).Attributes -band [IO.FileAttributes]::ReparsePoint)) {
    throw "$llamaDir ist ein Link; Installation abgebrochen."
}
$buildFile = Join-Path $llamaDir 'BUILD.txt'
$installedBuild = if (Test-Path -LiteralPath $buildFile) { [string](Get-Content -LiteralPath $buildFile -Raw) } else { '' }
$installedBuild = $installedBuild.Trim()
if ($installedBuild -ne $llamaBuild -or -not (Test-Path -LiteralPath (Join-Path $llamaDir 'llama-server.exe'))) {
    $release = "https://github.com/unslothai/llama.cpp/releases/download/$llamaBuild/"
    $name = if ($nvidia) { "app-$llamaBuild-windows-x64-cuda12-portable.zip" } else { "app-$llamaBuild-windows-x64-cpu.zip" }
    $stage = Join-Path $binDir ("llama.stage." + [guid]::NewGuid().ToString('N'))
    $backup = Join-Path $binDir ("llama.backup." + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $stage | Out-Null
    $embedWasRunning = $false
    $swapped = $false
    try {
        Expand-Release ($release + $name) $name $stage $hashes[$name]
        if (-not (Test-Path -LiteralPath (Join-Path $stage 'llama-server.exe'))) {
            throw 'llama-server.exe fehlt im Unsloth-Archiv.'
        }
        Set-Content -LiteralPath (Join-Path $stage 'BUILD.txt') -Value $llamaBuild -Encoding ASCII
        $embedTask = Get-ScheduledTask -TaskName 'Workbuddy-Embed' -ErrorAction SilentlyContinue
        $embedWasRunning = [bool]($embedTask -and $embedTask.State -eq 'Running')
        if ($embedWasRunning) { Stop-ScheduledTask -TaskName 'Workbuddy-Embed' }
        $llamaPrefix = [IO.Path]::GetFullPath($llamaDir).TrimEnd('\') + '\'
        Get-CimInstance Win32_Process -Filter "Name = 'llama-server.exe'" | ForEach-Object {
            if ($_.ExecutablePath -and $_.ExecutablePath.StartsWith($llamaPrefix, [StringComparison]::OrdinalIgnoreCase)) {
                Stop-Process -Id $_.ProcessId -Force -ErrorAction Stop
            }
        }
        if (Test-Path -LiteralPath $llamaDir) { Move-Item -LiteralPath $llamaDir -Destination $backup }
        Move-Item -LiteralPath $stage -Destination $llamaDir
        $swapped = $true
        if (Test-Path -LiteralPath $backup) {
            try { Remove-OwnDirectory $backup }
            catch { Write-Warning "Backup konnte nicht entfernt werden: $backup" }
        }
    } finally {
        if ((Test-Path -LiteralPath $backup) -and -not (Test-Path -LiteralPath $llamaDir)) {
            Move-Item -LiteralPath $backup -Destination $llamaDir
        }
        if (-not $swapped -and $embedWasRunning) {
            Start-ScheduledTask -TaskName 'Workbuddy-Embed' -ErrorAction SilentlyContinue
        }
        if (Test-Path -LiteralPath $stage) { Remove-OwnDirectory $stage }
    }
}
if (-not (Get-ChildItem -LiteralPath $whisperDir -Filter 'whisper-server.exe' -File -Recurse | Select-Object -First 1)) {
    $release = 'https://github.com/ggml-org/whisper.cpp/releases/download/b5454/'
    $cpuName = 'whisper-bin-x64.zip'
    if ($nvidia) {
        $name = 'whisper-bin-win-cuda-12.4.0-x64.zip'
        try { Expand-Release ($release + $name) $name $whisperDir $hashes[$name] }
        catch [System.IO.InvalidDataException] { throw }
        catch {
            Write-Host 'CUDA-Download fuer whisper.cpp fehlgeschlagen. Verwende CPU.'
            Expand-Release ($release + $cpuName) $cpuName $whisperDir $hashes[$cpuName]
        }
    } else {
        Expand-Release ($release + $cpuName) $cpuName $whisperDir $hashes[$cpuName]
    }
}
$llamaServer = Find-Server $llamaDir 'llama-server.exe'
$whisperServer = Find-Server $whisperDir 'whisper-server.exe'

Write-Host '7/8: Vier Dienste als Aufgaben einrichten ...'
$conhost = Join-Path $env:WINDIR 'System32\conhost.exe'
$embedArgs = '--headless "{0}" -m "{1}" --mmproj "{2}" --embedding --pooling mean -b 2048 -ub 2048 -ngl 99 --host 127.0.0.1 --port 18090 --sleep-idle-seconds 120' -f `
    $llamaServer, (Join-Path $modelDir 'embeddinggemma-2-Q8_0.gguf'), (Join-Path $modelDir 'mmproj-embeddinggemma-2-Q8_0.gguf')
$embedAction = New-ScheduledTaskAction -Execute $conhost -Argument $embedArgs
Register-ScheduledTask -TaskName 'Workbuddy-Embed' -Action $embedAction -Trigger $logon `
    -Principal $principal -Settings $longRunning -Force | Out-Null
$serviceScript = Join-Path $appDir 'fastsearch.py'
$searchAction = New-ScheduledTaskAction -Execute $venvPythonw `
    -Argument ('"{0}" serve --config "{1}"' -f $serviceScript, $config) -WorkingDirectory $appDir
Register-ScheduledTask -TaskName 'Workbuddy-Search' -Action $searchAction -Trigger $logon `
    -Principal $principal -Settings $longRunning -Force | Out-Null
# ponytail: The hourly trigger expires after 10 years; refresh it by running setup.ps1 again.
$hourly = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) `
    -RepetitionInterval (New-TimeSpan -Hours 1) -RepetitionDuration (New-TimeSpan -Days 3650)
$indexSettings = New-ScheduledTaskSettingsSet -Hidden -Priority 7 -ExecutionTimeLimit (New-TimeSpan -Hours 4) `
    -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew
$indexAction = New-ScheduledTaskAction -Execute $venvPythonw `
    -Argument ('"{0}" index --config "{1}"' -f $serviceScript, $config) -WorkingDirectory $appDir
Register-ScheduledTask -TaskName 'Workbuddy-Index' -Action $indexAction -Trigger $hourly `
    -Principal $principal -Settings $indexSettings -Force | Out-Null
$whisperArgs = '--headless "{0}" -m "{1}" --host 127.0.0.1 --port 18092 -l de --convert' -f `
    $whisperServer, (Join-Path $modelDir 'ggml-large-v3-turbo.bin')
$whisperAction = New-ScheduledTaskAction -Execute $conhost -Argument $whisperArgs
Register-ScheduledTask -TaskName 'Workbuddy-Whisper' -Action $whisperAction -Trigger $logon `
    -Principal $principal -Settings $longRunning -Force | Out-Null
foreach ($name in @('Workbuddy-Embed', 'Workbuddy-Search', 'Workbuddy-Whisper')) {
    $task = Get-ScheduledTask -TaskName $name
    if ($task.State -eq 'Running') { Stop-ScheduledTask -TaskName $name }
    Start-ScheduledTask -TaskName $name
}

Write-Host '8/8: FastSearch-Status pruefen ...'
$status = $null
for ($attempt = 0; $attempt -lt 30; $attempt++) {
    try {
        $status = Invoke-RestMethod -Uri 'http://127.0.0.1:18091/status' -TimeoutSec 2
        break
    } catch { Start-Sleep -Seconds 2 }
}
if (-not $status) {
    throw 'FastSearch antwortet nicht auf Port 18091. Bitte die Aufgaben Workbuddy-Search und Workbuddy-Embed in der Aufgabenplanung pruefen.'
}
Write-Host ($status | ConvertTo-Json -Compress -Depth 5)
Write-Host "Einrichtung abgeschlossen. Konfiguration: $config; Index: $localDir"
